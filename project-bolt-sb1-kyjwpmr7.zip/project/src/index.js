const express = require('express');
const cors = require('cors');
const { matchRouter } = require('./routes/matches');
const { teamRouter } = require('./routes/teams');
const { tournamentRouter } = require('./routes/tournaments');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Routes
app.use('/api/matches', matchRouter);
app.use('/api/teams', teamRouter);
app.use('/api/tournaments', tournamentRouter);

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});