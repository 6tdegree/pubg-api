export interface Team {
  id: string;
  name: string;
  players: Player[];
  created_at: string;
}

export interface Player {
  name: string;
  role: string;
}

export interface Tournament {
  id: string;
  name: string;
  start_date: string;
  end_date: string;
  created_at: string;
}

export interface Match {
  id: string;
  tournament_id: string;
  match_number: number;
  teams: MatchTeam[];
  created_at: string;
}

export interface MatchTeam {
  id: string;
  name: string;
  placement: number;
  kills: number;
  points: number;
}

export interface Standing {
  team_id: string;
  team_name: string;
  total_points: number;
  total_kills: number;
  matches_played: number;
  wins: number;
}