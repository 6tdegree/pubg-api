import { create } from 'zustand';
import { Tournament, Team, Match, Standing } from './types';
import { supabase } from './supabase';

interface Store {
  tournaments: Tournament[];
  teams: Team[];
  matches: Match[];
  standings: Standing[];
  currentTournament: Tournament | null;
  loading: boolean;
  error: string | null;
  fetchTournaments: () => Promise<void>;
  fetchTeams: () => Promise<void>;
  fetchMatches: (tournamentId: string) => Promise<void>;
  fetchStandings: (tournamentId: string) => Promise<void>;
  setCurrentTournament: (tournament: Tournament) => void;
}

export const useStore = create<Store>((set, get) => ({
  tournaments: [],
  teams: [],
  matches: [],
  standings: [],
  currentTournament: null,
  loading: false,
  error: null,

  fetchTournaments: async () => {
    set({ loading: true, error: null });
    try {
      const { data, error } = await supabase
        .from('tournaments')
        .select('*')
        .order('start_date', { ascending: false });

      if (error) throw error;
      set({ tournaments: data });
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  fetchTeams: async () => {
    set({ loading: true, error: null });
    try {
      const { data, error } = await supabase
        .from('teams')
        .select('*')
        .order('name');

      if (error) throw error;
      set({ teams: data });
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  fetchMatches: async (tournamentId: string) => {
    set({ loading: true, error: null });
    try {
      const { data, error } = await supabase
        .from('matches')
        .select('*')
        .eq('tournament_id', tournamentId)
        .order('match_number');

      if (error) throw error;
      set({ matches: data });
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  fetchStandings: async (tournamentId: string) => {
    set({ loading: true, error: null });
    try {
      const response = await fetch(`/api/tournaments/${tournamentId}/standings`);
      if (!response.ok) throw new Error('Failed to fetch standings');
      const data = await response.json();
      set({ standings: data });
    } catch (error) {
      set({ error: (error as Error).message });
    } finally {
      set({ loading: false });
    }
  },

  setCurrentTournament: (tournament: Tournament) => {
    set({ currentTournament: tournament });
  },
}));