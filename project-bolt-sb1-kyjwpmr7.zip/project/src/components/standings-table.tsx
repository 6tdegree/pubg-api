import { useEffect } from 'react';
import { useStore } from '@/lib/store';

export function StandingsTable() {
  const { currentTournament, standings, fetchStandings } = useStore();

  useEffect(() => {
    if (currentTournament) {
      fetchStandings(currentTournament.id);
    }
  }, [currentTournament, fetchStandings]);

  if (!currentTournament) return null;

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Tournament Standings</h2>
      <div className="rounded-md border">
        <table className="w-full">
          <thead>
            <tr className="border-b bg-muted/50">
              <th className="p-2 text-left">Rank</th>
              <th className="p-2 text-left">Team</th>
              <th className="p-2 text-right">Points</th>
              <th className="p-2 text-right">Kills</th>
              <th className="p-2 text-right">Matches</th>
              <th className="p-2 text-right">Wins</th>
            </tr>
          </thead>
          <tbody>
            {standings.map((standing, index) => (
              <tr key={standing.team_id} className="border-b">
                <td className="p-2">{index + 1}</td>
                <td className="p-2 font-medium">{standing.team_name}</td>
                <td className="p-2 text-right">{standing.total_points}</td>
                <td className="p-2 text-right">{standing.total_kills}</td>
                <td className="p-2 text-right">{standing.matches_played}</td>
                <td className="p-2 text-right">{standing.wins}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}