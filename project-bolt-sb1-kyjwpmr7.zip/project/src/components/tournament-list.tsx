import { useEffect } from 'react';
import { useStore } from '@/lib/store';
import { Button } from './ui/button';
import { format } from 'date-fns';

export function TournamentList() {
  const { tournaments, fetchTournaments, setCurrentTournament } = useStore();

  useEffect(() => {
    fetchTournaments();
  }, [fetchTournaments]);

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Tournaments</h2>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {tournaments.map((tournament) => (
          <div
            key={tournament.id}
            className="rounded-lg border bg-card text-card-foreground shadow-sm"
          >
            <div className="p-6">
              <h3 className="text-xl font-semibold">{tournament.name}</h3>
              <div className="mt-2 space-y-1 text-sm text-muted-foreground">
                <p>
                  Start: {format(new Date(tournament.start_date), 'PPP')}
                </p>
                <p>
                  End: {format(new Date(tournament.end_date), 'PPP')}
                </p>
              </div>
              <div className="mt-4">
                <Button
                  onClick={() => setCurrentTournament(tournament)}
                  className="w-full"
                >
                  View Details
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}