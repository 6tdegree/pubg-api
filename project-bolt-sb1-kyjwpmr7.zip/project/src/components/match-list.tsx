import { useEffect } from 'react';
import { useStore } from '@/lib/store';

export function MatchList() {
  const { currentTournament, matches, fetchMatches } = useStore();

  useEffect(() => {
    if (currentTournament) {
      fetchMatches(currentTournament.id);
    }
  }, [currentTournament, fetchMatches]);

  if (!currentTournament) return null;

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Match Results</h2>
      <div className="grid gap-4">
        {matches.map((match) => (
          <div
            key={match.id}
            className="rounded-lg border bg-card text-card-foreground shadow-sm"
          >
            <div className="p-4">
              <h3 className="text-lg font-semibold">
                Match #{match.match_number}
              </h3>
              <div className="mt-4">
                <table className="w-full">
                  <thead>
                    <tr className="border-b text-sm">
                      <th className="pb-2 text-left">Team</th>
                      <th className="pb-2 text-right">Placement</th>
                      <th className="pb-2 text-right">Kills</th>
                      <th className="pb-2 text-right">Points</th>
                    </tr>
                  </thead>
                  <tbody>
                    {match.teams
                      .sort((a, b) => a.placement - b.placement)
                      .map((team) => (
                        <tr key={team.id} className="border-b">
                          <td className="py-2">{team.name}</td>
                          <td className="py-2 text-right">#{team.placement}</td>
                          <td className="py-2 text-right">{team.kills}</td>
                          <td className="py-2 text-right">{team.points}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}