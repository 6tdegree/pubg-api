import { TournamentList } from './components/tournament-list';
import { StandingsTable } from './components/standings-table';
import { MatchList } from './components/match-list';
import { useStore } from './lib/store';

function App() {
  const { currentTournament } = useStore();

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="container py-4">
          <h1 className="text-3xl font-bold">PUBG Tournament Manager</h1>
        </div>
      </header>
      <main className="container py-8">
        {currentTournament ? (
          <div className="space-y-8">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">{currentTournament.name}</h2>
            </div>
            <div className="grid gap-8 lg:grid-cols-2">
              <StandingsTable />
              <MatchList />
            </div>
          </div>
        ) : (
          <TournamentList />
        )}
      </main>
    </div>
  );
}

export default App;