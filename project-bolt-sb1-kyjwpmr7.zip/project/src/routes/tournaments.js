const express = require('express');
const { supabase } = require('../utils/supabase');
const { calculateTournamentStandings } = require('../utils/standings');

const router = express.Router();

// Get all tournaments
router.get('/', async (req, res) => {
  const { data, error } = await supabase
    .from('tournaments')
    .select('*');
  
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// Get tournament standings
router.get('/:id/standings', async (req, res) => {
  const { id } = req.params;
  
  const { data: matches, error } = await supabase
    .from('matches')
    .select('*')
    .eq('tournament_id', id);

  if (error) return res.status(500).json({ error: error.message });
  
  const standings = calculateTournamentStandings(matches);
  res.json(standings);
});

module.exports = { tournamentRouter: router };