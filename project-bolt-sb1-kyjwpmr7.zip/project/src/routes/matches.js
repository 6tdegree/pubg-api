const express = require('express');
const { calculateMatchPoints } = require('../utils/pointCalculator');
const { supabase } = require('../utils/supabase');

const router = express.Router();

// Get all matches
router.get('/', async (req, res) => {
  const { data, error } = await supabase
    .from('matches')
    .select('*');
  
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// Create new match
router.post('/', async (req, res) => {
  const { tournament_id, match_number, teams } = req.body;
  
  const matchData = {
    tournament_id,
    match_number,
    teams: teams.map(team => ({
      ...team,
      points: calculateMatchPoints(team.placement, team.kills)
    }))
  };

  const { data, error } = await supabase
    .from('matches')
    .insert(matchData)
    .select();

  if (error) return res.status(500).json({ error: error.message });
  res.status(201).json(data[0]);
});

module.exports = { matchRouter: router };