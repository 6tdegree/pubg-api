const express = require('express');
const { supabase } = require('../utils/supabase');

const router = express.Router();

// Get all teams
router.get('/', async (req, res) => {
  const { data, error } = await supabase
    .from('teams')
    .select('*');
  
  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// Create new team
router.post('/', async (req, res) => {
  const { name, players } = req.body;
  
  const { data, error } = await supabase
    .from('teams')
    .insert({ name, players })
    .select();

  if (error) return res.status(500).json({ error: error.message });
  res.status(201).json(data[0]);
});

module.exports = { teamRouter: router };