function calculateTournamentStandings(matches) {
  const teamStats = {};

  // Process each match
  matches.forEach(match => {
    match.teams.forEach(team => {
      if (!teamStats[team.id]) {
        teamStats[team.id] = {
          team_id: team.id,
          team_name: team.name,
          total_points: 0,
          total_kills: 0,
          matches_played: 0,
          wins: 0
        };
      }

      teamStats[team.id].total_points += team.points;
      teamStats[team.id].total_kills += team.kills;
      teamStats[team.id].matches_played += 1;
      if (team.placement === 1) {
        teamStats[team.id].wins += 1;
      }
    });
  });

  // Convert to array and sort by total points
  return Object.values(teamStats)
    .sort((a, b) => b.total_points - a.total_points);
}

module.exports = {
  calculateTournamentStandings
};