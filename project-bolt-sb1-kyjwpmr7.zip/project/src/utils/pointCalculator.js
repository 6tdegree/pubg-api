// Default PUBG Mobile tournament point system
const PLACEMENT_POINTS = {
  1: 15,
  2: 12,
  3: 10,
  4: 8,
  5: 6,
  6: 4,
  7: 2,
  8: 1,
  9: 1,
  10: 1,
  11: 0,
  12: 0,
  13: 0,
  14: 0,
  15: 0,
  16: 0
};

const POINTS_PER_KILL = 1;

function calculateMatchPoints(placement, kills) {
  const placementPoints = PLACEMENT_POINTS[placement] || 0;
  const killPoints = kills * POINTS_PER_KILL;
  return placementPoints + killPoints;
}

module.exports = {
  calculateMatchPoints,
  PLACEMENT_POINTS,
  POINTS_PER_KILL
};