/*
  # Tournament System Schema

  1. New Tables
    - tournaments
      - id (uuid, primary key)
      - name (text)
      - start_date (timestamptz)
      - end_date (timestamptz)
      - created_at (timestamptz)
    
    - teams
      - id (uuid, primary key)
      - name (text)
      - players (jsonb)
      - created_at (timestamptz)
    
    - matches
      - id (uuid, primary key)
      - tournament_id (uuid, foreign key)
      - match_number (integer)
      - teams (jsonb)
      - created_at (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create tournaments table
CREATE TABLE IF NOT EXISTS tournaments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  start_date timestamptz NOT NULL,
  end_date timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create teams table
CREATE TABLE IF NOT EXISTS teams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  players jsonb NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create matches table
CREATE TABLE IF NOT EXISTS matches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tournament_id uuid REFERENCES tournaments(id),
  match_number integer NOT NULL,
  teams jsonb NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE tournaments ENABLE ROW LEVEL SECURITY;
ALTER TABLE teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE matches ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow read access to tournaments"
  ON tournaments FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Allow read access to teams"
  ON teams FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Allow read access to matches"
  ON matches FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Allow insert to tournaments"
  ON tournaments FOR INSERT TO authenticated
  WITH CHECK (true);

CREATE POLICY "Allow insert to teams"
  ON teams FOR INSERT TO authenticated
  WITH CHECK (true);

CREATE POLICY "Allow insert to matches"
  ON matches FOR INSERT TO authenticated
  WITH CHECK (true);